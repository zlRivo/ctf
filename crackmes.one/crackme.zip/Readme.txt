This is Overflow_ME by pranav.

This is another exploitation based challenge. To make things simple, there is no password, no check, none of unnecessary code. You have given access to the stack using scanf, and you are to find and make the program print the success message.

Launching the program in a console will wait for stdin. After an input is given, the program is set to message good bye, and exit. The success message saying you have cracked it is also embedded in the crackme, and there are ways to make the program print it. 

Printing the success message will count as a 50% completion, although you can stop and submit a writeup. There is a chance for the program to crash after printing the success message. To get 100% completion, You have to make sure program exits main() normally, by making sure "Good bye.." is also printed.


A failed attempt will crash the program to just prints "Good bye.."

A 50% completion will make the program print "Congragulations! You have cracked the exe!" and crash or quit.
A 100% completion will make it print above message and "Good bye.."


SHA1: 9FCFCC94EB020E8B4FC3EF47476DB347BB289850




















Special Mentions: Thank you @ori0n.x3 for the fantastic writeup on my previous crackme "Crackme_OF", I suggest all to look at the writeup as a reference. Also @giacomo270197 did a very pretty looking submission to my RE based crackme "SecureSoftware v1.5". Also check that out.